"""Freeze the reviewed source files and validate all four notes' local links."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOTES = HERE.parent
ROOT = HERE.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest_path = HERE / 'notes_manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
manifest['performanceAnalysisDate'] = '2026-09-16'
entries = []
for version, folder, names in [
    ('v16', 'hski_hair_audit', ['HskiHairContactMesh.cs', 'HskiHairSleeveContact.cs',
        'HskiHairJawContact.cs', 'HskiHairBodySurface.cs', 'HskiFaceSkinSurface.cs',
        'HskiHairLiveAudit.cs', 'HskiHairValidation.cs']),
    ('v37', 'actor_animation_solver', ['ActorAnimationSwingSolver.cs', 'HskiAutoWindDemoRecorder.cs']),
]:
    for name in names:
        source = ROOT / 'work' / folder / name
        snapshot = HERE / f'perf_{version}_{name}'
        # Preserve an already frozen snapshot; fail if its input changed.
        if snapshot.exists():
            assert sha(snapshot) == sha(source), f'Source changed: {source}'
        else:
            snapshot.write_bytes(source.read_bytes())
        entries.append({'source': str(source), 'snapshot': snapshot.name, 'sha256': sha(snapshot),
                        'scope': 'Reviewed source path; historical v16 release binary identity remains unverified'
                        if version == 'v16' else 'Reviewed current v37 source'})
manifest['performanceSources'] = entries
manifest['notes'] = []
links = 0
for path in sorted(NOTES.glob('0*.md')):
    content = path.read_text(encoding='utf-8-sig')
    manifest['notes'].append({'file': path.name, 'characters': len(content),
        'lines': len(content.splitlines()), 'sha256': sha(path)})
    for target in re.findall(r'\]\(([^)]+)\)', content):
        target = target.strip('<>')
        if re.match(r'^[A-Za-z]:[/\\]', target):
            assert Path(re.sub(r':\d+$', '', target)).exists(), f'Broken local link: {target}'
            links += 1
manifest['performanceArtifacts'] = [{'file': name, 'sha256': sha(HERE / name)} for name in
    ['analyze_performance.py', 'finalize_performance_notes.py', 'v37_performance_reanalysis.json',
     'v37_frame_intervals.png']]
manifest['linkCheck'] = f'all {links} local link occurrences exist across four notes'
manifest['performanceLimitations'] = [
    'Existing v37 short run only; no new player run and no comparable original v8/v16 timings.',
    'v37 frameMs is sample-to-EndOfFrame timing, not isolated solver CPU or complete wall-clock frame timing.',
    'Action-start spikes correlate with reset; no per-stage timing establishing causation.',
    'Static source analysis does not supply measured CPU/GPU/GC/memory cost rankings.'
]
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(f'Validated {len(manifest["notes"])} notes, {links} local links, {len(entries)} frozen performance sources.')
