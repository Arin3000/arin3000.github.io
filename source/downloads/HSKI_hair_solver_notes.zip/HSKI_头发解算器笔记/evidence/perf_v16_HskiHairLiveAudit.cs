﻿using System;
using System.IO;
using System.Collections;
using System.Text;
using UnityEngine;

// Runs the same Update/LateUpdate loop as the interactive player, including
// action wraparound. No Animator.Sample override and no manual hair stepping.
[DefaultExecutionOrder(600)]
public class HskiHairLiveAudit : MonoBehaviour {
    public HskiShowcase demo;
    const string Out="E:/ArinLee/简历/output/HSKI_EffectsPreview/hair_v16";
    IEnumerator Start(){if(Array.IndexOf(Environment.GetCommandLineArgs(),"-hairLiveAudit")<0)yield break;
        Directory.CreateDirectory(Out);yield return new WaitForEndOfFrame();demo.playing=false;yield return null;demo.SetAction(0);demo.view.showControls=false;
        var log=new StringBuilder("frame,loop,action,normalizedTime,deltaTime,faceBefore,faceAfter,bend,change,finite,jawAfter,handResidual,handShift\n");
        int loop=0,previous=demo.action,frames=0;bool[,] captured=new bool[3,3];bool valid=true;float start=Time.realtimeSinceStartup;
        while(loop<3&&Time.realtimeSinceStartup-start<50){
            yield return new WaitForEndOfFrame();int action=demo.action;if(previous==2&&action==0)loop++;previous=action;if(loop>=3)break;
            var bend=demo.hair.contactMesh.faceBend;float normalized=demo.actor.GetCurrentAnimatorStateInfo(0).normalizedTime;
            valid&=demo.hair.IsFinite&&bend.After<.001f;frames++;
            log.AppendLine($"{frames},{loop},{action},{normalized:F6},{Time.unscaledDeltaTime:F6},{bend.Before:F6},{bend.After:F6},{bend.MaxOffset:F6},{bend.PeakChange:F6},{demo.hair.IsFinite},{demo.hair.contactMesh.jawContact.After:F6},{demo.hair.contactMesh.handContact.Residual:F6},{demo.hair.contactMesh.handContact.Shift:F6}");
            if(action==2 && frames%4==0 && loop==0) {var tx=ScreenCapture.CaptureScreenshotAsTexture();File.WriteAllBytes(Out+"/live_dense_"+frames+".png",tx.EncodeToPNG());Destroy(tx);if(frames%12==0)demo.GetComponent<HskiHairGeometryAudit>().Dump(1000+frames);}
            if(action>=0&&normalized>.35f&&!captured[loop,action]){captured[loop,action]=true;var tex=ScreenCapture.CaptureScreenshotAsTexture();File.WriteAllBytes(Out+"/live_"+loop+"_"+action+".png",tex.EncodeToPNG());Destroy(tex);}
        }
        demo.SetAction(0);demo.hair.SetSimulation(false);yield return null;yield return new WaitForEndOfFrame();var body=demo.hair.contactMesh.surface.body;var rendered=body.transform.Find("Geo_Body_ContactPose").GetComponent<MeshFilter>().sharedMesh;var first=(Vector3[])rendered.vertices.Clone();yield return new WaitForSecondsRealtime(.3f);yield return new WaitForEndOfFrame();var second=rendered.vertices;float motion=0;for(int i=0;i<first.Length;i++)motion=Mathf.Max(motion,Vector3.Distance(first[i],second[i]));File.WriteAllText(Out+"/body_toggle_check.txt","Hair disabled: body vertex motion over 0.3 sec="+motion+"; continues animating="+(motion>.001f));demo.hair.SetSimulation(true);
        File.WriteAllText(Out+"/live_trace.csv",log.ToString());File.WriteAllText(Out+"/live_validation.txt",$"loops={loop}; frames={frames}; finite and sampled skin residual <1mm={valid}");Application.Quit(valid&&loop==3?0:2);
    }
}
