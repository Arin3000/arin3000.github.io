﻿using UnityEngine;
using System.Linq;

// Head-local front skin surface. Skin material triangles are supplied by the
// builder; eyelids/eyelines and other open overlay meshes are not colliders.
public class HskiFaceSkinSurface : MonoBehaviour {
    public Transform head;public SkinnedMeshRenderer face;public int[] skinTriangles;
    public Vector3[] LocalVertices{get;private set;}public Vector3[] LocalNormals{get;private set;}public int Version{get;private set;}int[] activeVertices;
    const int W=144,H=160;const float X0=-.10f,X1=.10f,Y0=-.035f,Y1=.165f;
    readonly float[] depth=new float[W*H];Mesh mesh;float[] shapeWeights;bool ready;
    public void Refresh(){
        bool changed=!ready;if(shapeWeights==null)shapeWeights=new float[face.sharedMesh.blendShapeCount];
        for(int i=0;i<shapeWeights.Length;i++){float w=face.GetBlendShapeWeight(i);changed|=Mathf.Abs(w-shapeWeights[i])>.00001f;shapeWeights[i]=w;}if(!changed)return;
        if(!mesh)mesh=new Mesh();face.BakeMesh(mesh);var p=mesh.vertices;var matrix=head.worldToLocalMatrix*face.transform.localToWorldMatrix;
        if(activeVertices==null)activeVertices=skinTriangles.Distinct().ToArray();var normals=mesh.normals;var normalMatrix=matrix.inverse.transpose;foreach(int i in activeVertices){p[i]=matrix.MultiplyPoint3x4(p[i]);normals[i]=normalMatrix.MultiplyVector(normals[i]).normalized;}LocalVertices=p;LocalNormals=normals;Version++;for(int i=0;i<depth.Length;i++)depth[i]=float.NegativeInfinity;
        for(int i=0;i<skinTriangles.Length;i+=3){var a=p[skinTriangles[i]];var b=p[skinTriangles[i+1]];var c=p[skinTriangles[i+2]];
            if(Mathf.Max(a.z,Mathf.Max(b.z,c.z))<.0f)continue;
            float den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Mathf.Abs(den)<1e-11f)continue;
            int l=Mathf.Max(0,Mathf.CeilToInt((Mathf.Min(a.x,Mathf.Min(b.x,c.x))-X0)/(X1-X0)*(W-1))),r=Mathf.Min(W-1,Mathf.FloorToInt((Mathf.Max(a.x,Mathf.Max(b.x,c.x))-X0)/(X1-X0)*(W-1)));
            int lo=Mathf.Max(0,Mathf.CeilToInt((Mathf.Min(a.y,Mathf.Min(b.y,c.y))-Y0)/(Y1-Y0)*(H-1))),hi=Mathf.Min(H-1,Mathf.FloorToInt((Mathf.Max(a.y,Mathf.Max(b.y,c.y))-Y0)/(Y1-Y0)*(H-1)));
            for(int y=lo;y<=hi;y++)for(int x=l;x<=r;x++){float px=Mathf.Lerp(X0,X1,x/(W-1f)),py=Mathf.Lerp(Y0,Y1,y/(H-1f));float wa=((b.y-c.y)*(px-c.x)+(c.x-b.x)*(py-c.y))/den;float wb=((c.y-a.y)*(px-c.x)+(a.x-c.x)*(py-c.y))/den;float wc=1-wa-wb;if(Mathf.Min(wa,Mathf.Min(wb,wc))<-.00001f)continue;depth[y*W+x]=Mathf.Max(depth[y*W+x],a.z*wa+b.z*wb+c.z*wc);}
        }ready=true;
    }
    public float Need(Vector3 p,float clearance){
        if(!ready||p.x<=X0||p.x>=X1||p.y<=Y0||p.y>=Y1||p.z<.015f)return 0;
        float fx=(p.x-X0)/(X1-X0)*(W-1),fy=(p.y-Y0)/(Y1-Y0)*(H-1);int x=Mathf.Min(W-2,(int)fx),y=Mathf.Min(H-2,(int)fy);float z=0,weight=0;
        for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){float v=depth[(y+dy)*W+x+dx];if(float.IsNegativeInfinity(v))continue;float w=(dx==0?1-fx+x:fx-x)*(dy==0?1-fy+y:fy-y);z+=v*w;weight+=w;}
        if(weight<.95f)return 0;return Mathf.Max(0,z/weight+clearance-p.z);
    }
    void OnDestroy(){if(mesh)Destroy(mesh);}
}
