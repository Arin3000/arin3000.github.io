﻿using System;
using System.Collections.Generic;
using UnityEngine;

// 3D skin contact for the long curls at the jaw silhouette. Unlike the front
// depth map this also covers the underside/side boundary of the chin.
public class HskiHairJawContact : MonoBehaviour {
 public HskiHairContactMesh contact;public HskiFaceSkinSurface skin;
 public float Before{get;private set;}public float After{get;private set;}public float MaxOffset{get;private set;}
 const float Margin=.006f,Limit=.016f;
 readonly HskiTriangleSurface surface=new HskiTriangleSurface();
 struct Query{public float need;public Vector3 normal;}
 int cachedVersion=-1;
 readonly Dictionary<Vector3Int,Query> queryCache=new Dictionary<Vector3Int,Query>();
 class Group{public HskiHairContactMesh.Binding b;public int[] map,ts;public List<int>[] members,near;public float[] free;public Vector3[] previous;}
 struct Constraint{public int a,b,c;public Vector3 weight,normal;public float need;}
 readonly List<Group> groups=new List<Group>();
 void Initialize(){foreach(var b in contact.bindings){var members=new List<List<int>>();var keys=new Dictionary<Vector3Int,int>();var map=new int[b.world.Length];
  for(int i=0;i<map.Length;i++){map[i]=-1;if(Mathf.Max(b.left[i],b.right[i])<.01f)continue;var p=contact.head.InverseTransformPoint(b.world[i]);var k=new Vector3Int(Mathf.RoundToInt(p.x*10000),Mathf.RoundToInt(p.y*10000),Mathf.RoundToInt(p.z*10000));if(!keys.TryGetValue(k,out int id)){id=members.Count;keys.Add(k,id);members.Add(new List<int>());}map[i]=id;members[id].Add(i);}
  var near=new List<int>[members.Count];var free=new float[members.Count];for(int i=0;i<near.Length;i++){near[i]=new List<int>();int id=members[i][0];float y=contact.head.InverseTransformPoint(b.world[id]).y;free[i]=Mathf.Clamp01(Mathf.Max(b.left[id],b.right[id])*2)*Mathf.SmoothStep(0,1,Mathf.InverseLerp(.075f,.005f,y));}
  var ts=new List<int>();var all=b.mesh.triangles;for(int t=0;t<all.Length;t+=3){if(map[all[t]]<0&&map[all[t+1]]<0&&map[all[t+2]]<0)continue;ts.Add(all[t]);ts.Add(all[t+1]);ts.Add(all[t+2]);for(int j=0;j<3;j++){int a=map[all[t+j]],c=map[all[t+(j+1)%3]];if(a<0||c<0||a==c)continue;if(!near[a].Contains(c))near[a].Add(c);if(!near[c].Contains(a))near[c].Add(a);}}
  groups.Add(new Group{b=b,map=map,members=members.ToArray(),near=near,free=free,previous=new Vector3[members.Count],ts=ts.ToArray()});
 }}
 float ExactNeed(Vector3 p,out Vector3 n){n=Vector3.zero;if(p.y<-.065f||p.y>.085f||Mathf.Abs(p.x)>.115f||p.z<-.015f)return 0;float s=surface.NearestWithin(p,p.z>.015f&&skin.Need(p,0)<=0?Margin+.0005f:.024f,out var closest,out n);if(float.IsInfinity(s)||s>=Margin)return 0;if(s<0&&Vector3.Dot((closest-p).normalized,n)<.6f)return 0;return Margin-s;}
 float Need(Vector3 p,out Vector3 n){n=Vector3.zero;if(p.y<-.065f||p.y>.085f||Mathf.Abs(p.x)>.115f||p.z<-.015f)return 0;const float cell=.0004f;var key=new Vector3Int(Mathf.RoundToInt(p.x/cell),Mathf.RoundToInt(p.y/cell),Mathf.RoundToInt(p.z/cell));if(!queryCache.TryGetValue(key,out var result)){float need=ExactNeed((Vector3)key*cell,out var normal);result=new Query{need=need>0?need+.00035f:0,normal=normal};queryCache.Add(key,result);}n=result.normal;return result.need;}
 void Add(List<Constraint> cs,Group g,Vector3[] p,int a,int b,int c,Vector3 w){var q=p[a]*w.x+p[b]*w.y+p[c]*w.z;float need=Need(q,out var n);if(need<=0)return;int ia=g.map[a],ib=g.map[b],ic=g.map[c];float f=(ia<0?0:g.free[ia]*w.x)+(ib<0?0:g.free[ib]*w.y)+(ic<0?0:g.free[ic]*w.z);if(f<.05f)return;Before=Mathf.Max(Before,Mathf.Max(0,need-Margin));cs.Add(new Constraint{a=ia,b=ib,c=ic,weight=w,normal=n,need=need});}
 Vector3 At(Vector3[] d,int i)=>i<0?Vector3.zero:d[i];
 public void ResetContact(){foreach(var g in groups)Array.Clear(g.previous,0,g.previous.Length);}
 public void Apply(bool advance,float dt){Before=After=MaxOffset=0;skin.Refresh();if(cachedVersion!=skin.Version||queryCache.Count>100000){queryCache.Clear();cachedVersion=skin.Version;}if(groups.Count==0)Initialize();surface.UpdateGeometry(skin.LocalVertices,skin.LocalNormals,skin.skinTriangles,skin.Version);
  foreach(var g in groups){if(g.members.Length==0)continue;var b=g.b;var p=new Vector3[b.world.Length];for(int i=0;i<p.Length;i++)p[i]=contact.head.InverseTransformPoint(b.world[i]);var d=new Vector3[g.members.Length];for(int i=0;i<d.Length;i++)d[i]=g.previous[i]*(advance?Mathf.Exp(-10*dt):1);var cs=new List<Constraint>();
   for(int i=0;i<d.Length;i++){int id=g.members[i][0];Add(cs,g,p,id,id,id,new Vector3(1,0,0));}
   for(int t=0;t<g.ts.Length;t+=3){int a=g.ts[t],c=g.ts[t+1],e=g.ts[t+2];Add(cs,g,p,a,c,e,Vector3.one/3);Add(cs,g,p,a,c,e,new Vector3(.5f,.5f,0));Add(cs,g,p,a,c,e,new Vector3(.5f,0,.5f));Add(cs,g,p,a,c,e,new Vector3(0,.5f,.5f));}
   for(int it=0;it<8;it++){var copy=(Vector3[])d.Clone();for(int i=0;i<d.Length;i++){Vector3 sum=Vector3.zero;foreach(int j in g.near[i])sum+=copy[j];if(g.near[i].Count>0)d[i]=Vector3.Lerp(copy[i],sum/g.near[i].Count,.2f);d[i]=Vector3.ClampMagnitude(d[i],Limit*g.free[i]);}
    foreach(var c in cs){var w=c.weight;float need=c.need-Vector3.Dot(At(d,c.a)*w.x+At(d,c.b)*w.y+At(d,c.c)*w.z,c.normal);if(need<=0)continue;float wa=c.a<0?0:w.x*g.free[c.a],wb=c.b<0?0:w.y*g.free[c.b],wc=c.c<0?0:w.z*g.free[c.c];float den=wa*w.x+wb*w.y+wc*w.z;if(den<.0001f)continue;var v=c.normal*(need/den);if(c.a>=0)d[c.a]=Vector3.ClampMagnitude(d[c.a]+v*wa,Limit*g.free[c.a]);if(c.b>=0)d[c.b]=Vector3.ClampMagnitude(d[c.b]+v*wb,Limit*g.free[c.b]);if(c.c>=0)d[c.c]=Vector3.ClampMagnitude(d[c.c]+v*wc,Limit*g.free[c.c]);}
   }
   var original=(Vector3[])b.world.Clone();for(int i=0;i<d.Length;i++){MaxOffset=Mathf.Max(MaxOffset,d[i].magnitude);foreach(int id in g.members[i])b.world[id]+=contact.head.TransformVector(d[i]);if(advance)g.previous[i]=d[i];int v=g.members[i][0];if(g.free[i]>.05f)After=Mathf.Max(After,Mathf.Max(0,Need(p[v]+d[i],out _)-Margin));}HskiHairSleeveContact.UpdateMesh(b,original,g.ts);
  }
 }
 void OnDestroy(){surface.Dispose();}
}
