using UnityEngine;

// A front depth field rasterized from the currently skinned torso, in chest
// coordinates. Unlike a fixed sphere, this follows the jacket through poses.
public class HskiHairBodySurface : MonoBehaviour
{
    public SkinnedMeshRenderer body;
    public Transform chest;
    public int[] torsoTriangles;
    const int W=80,H=96;
    const float X0=-.24f,X1=.24f,Y0=-.18f,Y1=.175f;
    readonly float[] depth=new float[W*H];
    readonly float[] conservativeDepth=new float[W*H];
    Mesh baked;Vector3[] points;int[] triangles;
    public void Refresh()
    {
        if(!body||!chest)return;
        if(!baked)baked=new Mesh{name="Hair torso collision bake"};
        body.BakeMesh(baked);var vertices=baked.vertices;
        if(triangles==null)triangles=torsoTriangles!=null&&torsoTriangles.Length>0?torsoTriangles:baked.triangles;
        if(points==null||points.Length!=vertices.Length)points=new Vector3[vertices.Length];
        var matrix=chest.worldToLocalMatrix*body.transform.localToWorldMatrix;
        for(int i=0;i<vertices.Length;i++)points[i]=matrix.MultiplyPoint3x4(vertices[i]);
        for(int i=0;i<depth.Length;i++)depth[i]=float.NegativeInfinity;
        for(int i=0;i<triangles.Length;i+=3){
            var a=points[triangles[i]];var b=points[triangles[i+1]];var c=points[triangles[i+2]];
            // Exclude hands/arms projected in front of the torso. The jacket's
            // front surface lies within this chest-local depth interval.
            if(Mathf.Min(a.z,Mathf.Min(b.z,c.z))>.23f||Mathf.Max(a.z,Mathf.Max(b.z,c.z))<-.16f)continue;
            int l=Mathf.Max(0,Mathf.CeilToInt((Mathf.Min(a.x,Mathf.Min(b.x,c.x))-X0)/(X1-X0)*(W-1)));
            int r=Mathf.Min(W-1,Mathf.FloorToInt((Mathf.Max(a.x,Mathf.Max(b.x,c.x))-X0)/(X1-X0)*(W-1)));
            int d=Mathf.Max(0,Mathf.CeilToInt((Mathf.Min(a.y,Mathf.Min(b.y,c.y))-Y0)/(Y1-Y0)*(H-1)));
            int u=Mathf.Min(H-1,Mathf.FloorToInt((Mathf.Max(a.y,Mathf.Max(b.y,c.y))-Y0)/(Y1-Y0)*(H-1)));
            float denominator=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);
            if(Mathf.Abs(denominator)<1e-10f)continue;
            for(int y=d;y<=u;y++)for(int x=l;x<=r;x++){
                float px=Mathf.Lerp(X0,X1,x/(W-1f)),py=Mathf.Lerp(Y0,Y1,y/(H-1f));
                float wa=((b.y-c.y)*(px-c.x)+(c.x-b.x)*(py-c.y))/denominator;
                float wb=((c.y-a.y)*(px-c.x)+(a.x-c.x)*(py-c.y))/denominator;float wc=1-wa-wb;
                if(wa<-.0001f||wb<-.0001f||wc<-.0001f)continue;
                float z=wa*a.z+wb*b.z+wc*c.z;
                if(z<=.23f)depth[y*W+x]=Mathf.Max(depth[y*W+x],z);
            }
        }
        for(int y=0;y<H;y++)for(int x=0;x<W;x++){
            float z=float.NegativeInfinity;
            for(int yy=Mathf.Max(0,y-1);yy<=Mathf.Min(H-1,y+1);yy++)for(int xx=Mathf.Max(0,x-1);xx<=Mathf.Min(W-1,x+1);xx++)z=Mathf.Max(z,depth[yy*W+xx]);
            conservativeDepth[y*W+x]=z;
        }
    }
    public float Penetration(Vector3 world,float clearance,out Vector3 corrected)
    {
        corrected=world;if(!chest||points==null)return 0;
        var p=chest.InverseTransformPoint(world);
        if(p.x<X0||p.x>X1||p.y<Y0||p.y>Y1)return 0;
        float fx=(p.x-X0)/(X1-X0)*(W-1),fy=(p.y-Y0)/(Y1-Y0)*(H-1);
        int x=Mathf.Min(W-2,Mathf.FloorToInt(fx)),y=Mathf.Min(H-2,Mathf.FloorToInt(fy));
        float z=0,weight=0;
        for(int yy=0;yy<2;yy++)for(int xx=0;xx<2;xx++){
            float d=conservativeDepth[(y+yy)*W+x+xx];if(float.IsNegativeInfinity(d))d=-.20f;
            float w=(xx==0?1-(fx-x):fx-x)*(yy==0?1-(fy-y):fy-y);z+=d*w;weight+=w;
        }
        if(weight<.00001f||p.z<-.20f)return 0;z/=weight;
        float amount=Mathf.Max(0,z+clearance-p.z);
        if(amount>0){p.z+=amount;corrected=chest.TransformPoint(p);}
        return amount;
    }
    void OnDestroy(){if(baked)Destroy(baked);}
}
