﻿using System;
using System.IO;
using System.Collections;
using System.Text;
using UnityEngine;
[DefaultExecutionOrder(450)]
public class HskiHairValidation : MonoBehaviour {
 public HskiShowcase demo;public HskiHairDynamics hair;
 const string Root="E:/ArinLee/简历/output/HSKI_EffectsPreview";
 IEnumerator Start(){
 bool bake=Array.IndexOf(Environment.GetCommandLineArgs(),"-hairBake")>=0;var frames=new System.Collections.Generic.List<HskiHairSleeveContact.Frame>();bool record=Array.IndexOf(Environment.GetCommandLineArgs(),"-hairRecord")>=0,smoke=Array.IndexOf(Environment.GetCommandLineArgs(),"-hairSmoke")>=0;
 if(!record&&!smoke&&!bake)yield break;yield return null;
 demo.enabled=false;demo.playing=false;demo.view.showControls=false;hair.manualSimulation=true;
 Directory.CreateDirectory(Root+"/hair_v16");Directory.CreateDirectory(Root+"/showcase_v16_frames");
 var log=new StringBuilder("fps,frame,action,finite,frontBoneDeviation,sleeveBefore,sleeveAfter,sleeveOffset,faceBefore,faceAfter,faceBend,faceChange,authoredScalpOverlap,jawBefore,jawAfter,jawOffset,handShift,handResidual,handCompression\n");bool valid=true;
 foreach(int fps in (record||bake)?new[]{30}:new[]{30,60,120}){
 int first=Mathf.RoundToInt(demo.durations[0]*fps),second=Mathf.RoundToInt(demo.durations[1]*fps),total=first+second+Mathf.RoundToInt(demo.durations[2]*fps),current=-1;
 for(int frame=0;frame<total;frame++){

 int action=frame<first?0:frame<first+second?1:2;
 if(action!=current){current=action;demo.SetAction(action);demo.playing=false;}
 int offset=action==0?0:action==1?first:first+second;
 demo.Sample((frame-offset)/(float)fps);demo.SendMessage("ApplyDetails");hair.Step(1f/fps);
 var b=hair.contactMesh.faceBend;var s=hair.contactMesh.sleeveContact;if(bake)frames.Add(s.Export(action,(frame-offset)/(float)fps));valid&=hair.IsFinite&&s.MaxOffset<=.0321f&&hair.FrontRootDrift<.00001f&&b.After<.001f;
 log.AppendLine($"{fps},{frame},{action},{hair.IsFinite},{hair.FrontHairDeviation:F6},{s.Before:F6},{s.After:F6},{s.MaxOffset:F6},{b.Before:F6},{b.After:F6},{b.MaxOffset:F6},{b.PeakChange:F6},{b.AuthoredScalpOverlap:F6},{hair.contactMesh.jawContact.Before:F6},{hair.contactMesh.jawContact.After:F6},{hair.contactMesh.jawContact.MaxOffset:F6},{hair.contactMesh.handContact.Shift:F6},{hair.contactMesh.handContact.Residual:F6},{hair.contactMesh.handContact.Compression:F6}");
 if(record){if(frame==20||frame==34||frame==50||frame==163||frame==167||frame==170||frame==171||frame==175||frame==180||frame==185||frame==195||frame==225||frame==250||frame==280)demo.GetComponent<HskiHairGeometryAudit>().Dump(frame);if(frame==0)for(int warm=0;warm<3;warm++)yield return new WaitForEndOfFrame();yield return new WaitForEndOfFrame();var tex=ScreenCapture.CaptureScreenshotAsTexture();File.WriteAllBytes(Root+"/showcase_v16_frames/"+frame.ToString("D4")+".png",tex.EncodeToPNG());Destroy(tex);}else if(frame%30==0)yield return null;
 if(frame%100==0)Debug.Log("HSKI_V16_FRAME="+frame+" FPS="+fps);
 }}
 if(bake)File.WriteAllText(Root+"/hair_v16/HskiSleeveContactClip.json",JsonUtility.ToJson(new HskiHairSleeveContact.Library{frames=frames.ToArray()}));File.WriteAllText(Root+"/hair_v16/"+(bake?"bake_trace.csv":record?"record_trace.csv":"smoke_trace.csv"),log.ToString());
 File.WriteAllText(Root+"/hair_v16/"+(record?"recording.txt":"validation.txt"),"Finite solver / root attachment / sleeve <=32 mm / sampled skin residual <1 mm: "+valid+". Sleeve residual is a local signed-distance diagnostic, not a guarantee of full-mesh nonintersection.");Application.Quit(valid?0:2);
 }
}




